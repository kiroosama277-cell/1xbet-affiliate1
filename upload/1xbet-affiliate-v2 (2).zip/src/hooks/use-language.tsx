"use client";

import { createContext, useContext, useState, useCallback, ReactNode } from "react";

export type Lang = "ar" | "en";

export const translations = {
  ar: {
    // Nav
    navPromo: "البروموكود",
    navSteps: "الخطوات",
    navProgram: "البرنامج",
    navWithdraw: "السحب",
    navRegister: "التسجيل",
    headerCta: "كن شريكًا",

    // Hero
    heroEyebrow: "1XBET Affiliate Program",
    heroTitleLead: "سجّل كشريك تسويق واحصل على",
    heroCopy: "واجهة تسجيل مصممة لجمع بيانات الشريك، مصدر الزيارات، والكود المقترح في نموذج واحد سريع وواضح، مع تجربة استخدام احترافية تناسب حملات التسويق.",
    heroPrimary: "ابدأ التسجيل",
    heroSecondary: "عرض التفاصيل",
    heroStat1Label: "الحد الأدنى للسحب",
    heroStat1Value: "$30",
    heroStat2Label: "لاعبين نشطين",
    heroStat2Value: "3+",
    heroStat3Label: "محافظ كريبتو",
    heroStat3Value: "6+",

    // Notice
    noticeTitle: "طلب واحد منظم",
    noticeCopy: "أرسل بيانات الشريك ومصدر الزيارات والكود المقترح. بعد المراجعة، يمكن ربط الطلب بمسؤول المبيعات أو لوحة متابعة خاصة.",
    noticeCta: "تقديم الطلب",

    // Promo Intro
    promoKicker: "عن البروموكود",
    promoTitle: "واحصل على بروموكود مخصص لحملاتك",
    promoCopy: "البروموكود هو كود تسويقي مخصص يساعد على تمييز طلبات الشريك وربطها بمصدر الزيارات. املأ بياناتك، اختر كودًا واضحًا، وابدأ مسار المراجعة.",

    // Phrases for typing effect
    phrases: ["بروموكود مخصص", "رابط شريك واضح", "طلب قابل للمتابعة"],

    // Horizontal scroll cards
    card1Title: "بيانات الشريك",
    card1Desc: "الاسم والبريد ورقم الهاتف والدولة — كل ما يلزم لتسجيل الشريك.",
    card2Title: "مصدر الزيارات",
    card2Desc: "حدد القناة التسويقية الرئيسية (تيليجرام، فيسبوك، تيك توك، إلخ).",
    card3Title: "البروموكود",
    card3Desc: "اختر كودًا واضحًا وسهل التذكر لربطه بحملاتك.",
    card4Title: "التقارير",
    card4Desc: "تتبّع نتائجك من خلال تقارير الحساب واختيار الفترات المناسبة.",
    card5Title: "السحب",
    card5Desc: "اسحب أرباحك عبر حساب اللاعب أو محفظة كريبتو بعد الوصول للحد الأدنى.",

    // Steps
    step1Title: "أنشئ حسابك",
    step1Desc: "سجّل بياناتك الأساسية: الاسم، البريد الإلكتروني، رقم الهاتف، والدولة.",
    step2Title: "اختر مصدر الزيارات",
    step2Desc: "حدد القناة التسويقية التي ستجلب منها الزيارات.",
    step3Title: "اقترح بروموكود",
    step3Desc: "اختر كودًا تسويقيًا واضحًا يُربط بحسابك.",
    step4Title: "انتظر المراجعة",
    step4Desc: "بعد المراجعة، ستتلقى رابط الشريك والبوموكود المخصص.",
    stepsKicker: "خطوات التسجيل",
    stepsTitle: "أربع خطوات بسيطة للبدء",

    // Program Details
    programKicker: "تفاصيل البرنامج",
    programTitle: "كل ما تحتاج معرفته",
    detailAge: "18+",
    detailAgeLabel: "الحد الأدنى للعمر",
    detailMin: "$30",
    detailMinLabel: "الحد الأدنى للسحب",
    detailPeriod: "إثنين - أحد",
    detailPeriodLabel: "فترة الاحتساب",
    detailDay: "الثلاثاء",
    detailDayLabel: "يوم المعالجة",

    // Withdrawal
    withdrawKicker: "السحب والعمولة",
    withdrawTitle: "قواعد السحب وهيكل العمولة",
    withdrawRulesTitle: "قواعد السحب",
    rule1Title: "حساب اللاعب",
    rule1Desc: "3+ لاعبين نشطين",
    rule2Title: "محفظة كريبتو",
    rule2Desc: "6+ لاعبين نشطين",
    rule3Title: "تتبع النتائج",
    rule3Desc: "تقارير اللاعبين",
    rule4Title: "بريد الدعم",
    rule4Desc: "support@partners1xbet.com",
    commissionEgypt: "مصر",
    commissionOther: "دول أخرى",
    commissionFtd: "FTD",
    commissionRate: "العمولة",
    commissionStructure: "هيكل العمولة",
    egyptTier1: "0-50",
    egyptTier2: "51-100",
    egyptTier3: "101-350",
    egyptTier4: "351+",
    otherTier1: "500-799",
    otherTier2: "800-1000",
    otherTier3: "1000+",

    // Form
    formKicker: "التسجيل",
    formTitle: "قدّم طلبك الآن",
    formName: "الاسم الكامل",
    formNamePlaceholder: "أدخل اسمك الكامل",
    formEmail: "البريد الإلكتروني",
    formEmailPlaceholder: "example@email.com",
    formPhone: "رقم الهاتف",
    formPhonePlaceholder: "+20 xxx xxx xxxx",
    formCountry: "الدولة",
    formCountryPlaceholder: "اختر دولتك",
    formPromo: "البروموكود المقترح",
    formPromoPlaceholder: "مثال: PARTNER2024",
    formPromoPreview: "معاينة البروموكود",
    formTraffic: "مصدر الزيارات",
    formTrafficPlaceholder: "اختر مصدر الزيارات",
    formChannel: "وصف القناة",
    formChannelPlaceholder: "صف قناتك التسويقية بإيجاز...",
    formSubmit: "تقديم الطلب",
    formSubmitting: "جارٍ التقديم...",
    formSuccess: "تم تقديم الطلب بنجاح!",
    formError: "حدث خطأ، حاول مرة أخرى",

    // Countries
    countryEgypt: "مصر",
    countrySaudi: "السعودية",
    countryUAE: "الإمارات",
    countryMorocco: "المغرب",
    countryAlgeria: "الجزائر",
    countryIraq: "العراق",
    countryJordan: "الأردن",
    countryOther: "أخرى",

    // Traffic sources
    trafficTelegram: "تيليجرام",
    trafficFacebook: "فيسبوك",
    trafficTiktok: "تيك توك",
    trafficYoutube: "يوتيوب",
    trafficWebsite: "موقع إلكتروني",
    trafficOther: "أخرى",

    // FAQ
    faqKicker: "الأسئلة الشائعة",
    faqTitle: "إجابات على أسئلتك",
    faq1Q: "ما البيانات المطلوبة لتسجيل الطلب؟",
    faq1A: "الاسم والعائلة، رقم الهاتف، البريد الإلكتروني، الدولة، مصدر الزيارات، والبروموكود المقترح.",
    faq2Q: "كيف تتم متابعة النتائج؟",
    faq2A: "تتم متابعة الأداء من خلال تقارير الحساب واختيار الفترة المناسبة لعرض النتائج.",
    faq3Q: "هل العمولة ثابتة؟",
    faq3A: "العمولة ترتبط بأداء المستخدمين الجدد وشرائح FTD وطريقة احتساب الأرباح.",

    // Footer
    footerDesc: "1XBET Affiliate Program — منصة تسويق احترافية لشركاء النمو. سجّل الآن واحصل على بروموكود مخصص وحملات تتبع متكاملة.",
    footerCopy: "© 2024 1XBET Affiliate. جميع الحقوق محفوظة.",

    // Contact
    contactBadge: "اتصل بنا",
    contactTitle: "تواصل معنا بسهولة",
    contactDesc: "يمكنك التواصل معنا من خلال وسائل التواصل الاجتماعي أو عبر الهاتف. نحن هنا لمساعدتك في أي استفسار أو مشكلة تواجهك.",
    contactTelegram: "تيليجرام",
    contactTelegramDesc: "للتواصل عبر تيليجرام، يمكنك إرسال رسالة إلى الحساب التالي:",
    contactWhatsApp: "واتساب",
    contactWhatsAppDesc: "للتواصل المباشر عبر واتساب، يمكنك استخدام الرقم التالي:",

    // Preloader
    preloaderText: "جارٍ التحميل",
  },
  en: {
    // Nav
    navPromo: "Promo Code",
    navSteps: "Steps",
    navProgram: "Program",
    navWithdraw: "Payout",
    navRegister: "Register",
    headerCta: "Become Partner",

    // Hero
    heroEyebrow: "1XBET Affiliate Program",
    heroTitleLead: "Register as a partner and get a",
    heroCopy: "A premium registration flow for partner details, traffic source, and proposed promo code in one clear form built for campaign teams.",
    heroPrimary: "Start Registration",
    heroSecondary: "View Details",
    heroStat1Label: "Min. Withdrawal",
    heroStat1Value: "$30",
    heroStat2Label: "Active Players",
    heroStat2Value: "3+",
    heroStat3Label: "Crypto Wallets",
    heroStat3Value: "6+",

    // Notice
    noticeTitle: "One Organized Request",
    noticeCopy: "Submit partner details, traffic source, and proposed promo code. After review, the request can be assigned to a sales owner or tracking dashboard.",
    noticeCta: "Submit Request",

    // Promo Intro
    promoKicker: "About Promo Codes",
    promoTitle: "Get a dedicated promo code for your campaigns",
    promoCopy: "A promo code is a dedicated marketing code used to identify partner requests and connect them with a traffic source. Fill in your details, choose a clean code, and start the review flow.",

    // Phrases for typing effect
    phrases: ["Dedicated Promo Code", "Clear Partner Link", "Trackable Request"],

    // Horizontal scroll cards
    card1Title: "Partner Details",
    card1Desc: "Name, email, phone, and country — everything needed to register a partner.",
    card2Title: "Traffic Source",
    card2Desc: "Specify the main marketing channel (Telegram, Facebook, TikTok, etc.).",
    card3Title: "Promo Code",
    card3Desc: "Choose a clear and memorable code to link with your campaigns.",
    card4Title: "Reports",
    card4Desc: "Track your results through account reports by selecting appropriate periods.",
    card5Title: "Withdrawal",
    card5Desc: "Withdraw earnings via player account or crypto wallet after reaching the minimum.",

    // Steps
    step1Title: "Create Your Account",
    step1Desc: "Register your basic info: name, email, phone number, and country.",
    step2Title: "Choose Traffic Source",
    step2Desc: "Select the marketing channel that will drive your traffic.",
    step3Title: "Propose a Promo Code",
    step3Desc: "Choose a clear marketing code to link with your account.",
    step4Title: "Wait for Review",
    step4Desc: "After review, you'll receive your partner link and dedicated promo code.",
    stepsKicker: "Registration Steps",
    stepsTitle: "Four Simple Steps to Get Started",

    // Program Details
    programKicker: "Program Details",
    programTitle: "Everything You Need to Know",
    detailAge: "18+",
    detailAgeLabel: "Minimum Age",
    detailMin: "$30",
    detailMinLabel: "Min. Withdrawal",
    detailPeriod: "Mon - Sun",
    detailPeriodLabel: "Calculation Period",
    detailDay: "Tuesday",
    detailDayLabel: "Processing Day",

    // Withdrawal
    withdrawKicker: "Payout & Commission",
    withdrawTitle: "Withdrawal Rules & Commission Structure",
    withdrawRulesTitle: "Withdrawal Rules",
    rule1Title: "Player Account",
    rule1Desc: "3+ active players",
    rule2Title: "Crypto Wallet",
    rule2Desc: "6+ active players",
    rule3Title: "Results Tracking",
    rule3Desc: "Player Report",
    rule4Title: "Support Email",
    rule4Desc: "support@partners1xbet.com",
    commissionEgypt: "Egypt",
    commissionOther: "Other Countries",
    commissionFtd: "FTD",
    commissionRate: "Commission",
    commissionStructure: "Commission Structure",
    egyptTier1: "0-50",
    egyptTier2: "51-100",
    egyptTier3: "101-350",
    egyptTier4: "351+",
    otherTier1: "500-799",
    otherTier2: "800-1000",
    otherTier3: "1000+",

    // Form
    formKicker: "Registration",
    formTitle: "Submit Your Request Now",
    formName: "Full Name",
    formNamePlaceholder: "Enter your full name",
    formEmail: "Email Address",
    formEmailPlaceholder: "example@email.com",
    formPhone: "Phone Number",
    formPhonePlaceholder: "+1 xxx xxx xxxx",
    formCountry: "Country",
    formCountryPlaceholder: "Select your country",
    formPromo: "Proposed Promo Code",
    formPromoPlaceholder: "e.g. PARTNER2024",
    formPromoPreview: "Promo Code Preview",
    formTraffic: "Traffic Source",
    formTrafficPlaceholder: "Select traffic source",
    formChannel: "Channel Description",
    formChannelPlaceholder: "Briefly describe your marketing channel...",
    formSubmit: "Submit Request",
    formSubmitting: "Submitting...",
    formSuccess: "Request submitted successfully!",
    formError: "An error occurred, please try again",

    // Countries
    countryEgypt: "Egypt",
    countrySaudi: "Saudi Arabia",
    countryUAE: "UAE",
    countryMorocco: "Morocco",
    countryAlgeria: "Algeria",
    countryIraq: "Iraq",
    countryJordan: "Jordan",
    countryOther: "Other",

    // Traffic sources
    trafficTelegram: "Telegram",
    trafficFacebook: "Facebook",
    trafficTiktok: "TikTok",
    trafficYoutube: "YouTube",
    trafficWebsite: "Website",
    trafficOther: "Other",

    // FAQ
    faqKicker: "FAQ",
    faqTitle: "Answers to Your Questions",
    faq1Q: "What data is required to register?",
    faq1A: "Full name, phone number, email address, country, traffic source, and proposed promo code.",
    faq2Q: "How are results tracked?",
    faq2A: "Performance is tracked through account reports by selecting the appropriate period to view results.",
    faq3Q: "Is the commission fixed?",
    faq3A: "The commission is tied to new user performance, FTD tiers, and profit calculation method.",

    // Footer
    footerDesc: "1XBET Affiliate Program — A professional marketing platform for growth partners. Register now and get a dedicated promo code with integrated tracking campaigns.",
    footerCopy: "© 2024 1XBET Affiliate. All rights reserved.",

    // Contact
    contactBadge: "Contact Us",
    contactTitle: "Get in Touch Easily",
    contactDesc: "You can reach us through social media or by phone. We're here to help with any inquiry or issue you may have.",
    contactTelegram: "Telegram",
    contactTelegramDesc: "To contact us via Telegram, send a message to the following account:",
    contactWhatsApp: "WhatsApp",
    contactWhatsAppDesc: "For direct contact via WhatsApp, you can use the following number:",

    // Preloader
    preloaderText: "Loading",
  },
} as const;

export type Translations = typeof translations.ar;

interface LanguageContextType {
  lang: Lang;
  t: Translations;
  setLang: (lang: Lang) => void;
  isRTL: boolean;
}

const LanguageContext = createContext<LanguageContextType | null>(null);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>("ar");

  const setLang = useCallback((newLang: Lang) => {
    setLangState(newLang);
  }, []);

  const t = translations[lang];
  const isRTL = lang === "ar";

  return (
    <LanguageContext.Provider value={{ lang, t, setLang, isRTL }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error("useLanguage must be used within a LanguageProvider");
  }
  return context;
}
