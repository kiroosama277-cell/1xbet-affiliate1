import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { name, email, phone, country, promoCode, trafficSource, channelDesc, refCode } = body;

    // Validate required fields
    if (!name?.trim() || !email?.trim() || !phone?.trim() || !country || !promoCode?.trim() || !trafficSource) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
    }

    // Find the sales ref if a refCode was provided
    let salesRefId: string | null = null;
    if (refCode) {
      const salesRef = await db.salesRef.findUnique({ where: { code: refCode } });
      if (salesRef) {
        salesRefId = salesRef.id;
      }
    }

    // Save the registration
    const registration = await db.registration.create({
      data: {
        name: name.trim(),
        email: email.trim(),
        phone: phone.trim(),
        country,
        promoCode: promoCode.trim().toUpperCase(),
        trafficSource,
        channelDesc: channelDesc?.trim() || null,
        refCode: refCode || null,
        salesRefId,
      },
    });

    return NextResponse.json({ success: true, id: registration.id }, { status: 201 });
  } catch (error: any) {
    console.error("Registration error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
