import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// GET /api/admin/registrations - list all registrations
export async function GET() {
  try {
    const registrations = await db.registration.findMany({
      orderBy: { createdAt: "desc" },
      include: {
        salesRef: { select: { id: true, code: true, name: true } },
      },
    });
    return NextResponse.json(registrations);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed to fetch registrations" }, { status: 500 });
  }
}
