import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// GET /api/admin/refs - list all sales refs
export async function GET() {
  try {
    const refs = await db.salesRef.findMany({
      orderBy: { createdAt: "desc" },
      include: {
        _count: { select: { registrations: true } },
      },
    });
    return NextResponse.json(refs);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed to fetch refs" }, { status: 500 });
  }
}

// POST /api/admin/refs - create a new sales ref
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { code, name, email, phone } = body;

    if (!code?.trim() || !name?.trim()) {
      return NextResponse.json({ error: "Code and name are required" }, { status: 400 });
    }

    // Check if code already exists
    const existing = await db.salesRef.findUnique({ where: { code: code.trim().toLowerCase() } });
    if (existing) {
      return NextResponse.json({ error: "This code already exists" }, { status: 409 });
    }

    const ref = await db.salesRef.create({
      data: {
        code: code.trim().toLowerCase(),
        name: name.trim(),
        email: email?.trim() || null,
        phone: phone?.trim() || null,
      },
    });

    return NextResponse.json(ref, { status: 201 });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed to create ref" }, { status: 500 });
  }
}

// DELETE /api/admin/refs?id=xxx - delete a sales ref
export async function DELETE(req: NextRequest) {
  try {
    const id = req.nextUrl.searchParams.get("id");
    if (!id) {
      return NextResponse.json({ error: "ID is required" }, { status: 400 });
    }

    await db.salesRef.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed to delete ref" }, { status: 500 });
  }
}
