"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";

// Simple admin password - in production you'd use proper auth
const ADMIN_PASSWORD = "1xbet2024";

type Registration = {
  id: string;
  name: string;
  email: string;
  phone: string;
  country: string;
  promoCode: string;
  trafficSource: string;
  channelDesc: string | null;
  refCode: string | null;
  salesRefId: string | null;
  createdAt: string;
  salesRef?: { id: string; code: string; name: string } | null;
};

type SalesRef = {
  id: string;
  code: string;
  name: string;
  email: string | null;
  phone: string | null;
  createdAt: string;
  _count: { registrations: number };
};

export default function AdminPage() {
  const [isAuthed, setIsAuthed] = useState(false);
  const [password, setPassword] = useState("");
  const [authError, setAuthError] = useState("");
  const [activeTab, setActiveTab] = useState<"registrations" | "refs">("registrations");
  const [registrations, setRegistrations] = useState<Registration[]>([]);
  const [salesRefs, setSalesRefs] = useState<SalesRef[]>([]);
  const [loading, setLoading] = useState(false);
  const [showAddRef, setShowAddRef] = useState(false);
  const [newRef, setNewRef] = useState({ code: "", name: "", email: "", phone: "" });
  const [siteUrl, setSiteUrl] = useState("");

  useEffect(() => {
    setSiteUrl(window.location.origin);
  }, []);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === ADMIN_PASSWORD) {
      setIsAuthed(true);
      setAuthError("");
      fetchData();
    } else {
      setAuthError("كلمة السر غلط");
    }
  };

  const fetchData = async () => {
    setLoading(true);
    try {
      const [regRes, refRes] = await Promise.all([
        fetch("/api/admin/registrations"),
        fetch("/api/admin/refs"),
      ]);
      if (regRes.ok) setRegistrations(await regRes.json());
      if (refRes.ok) setSalesRefs(await refRes.json());
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleAddRef = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch("/api/admin/refs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newRef),
      });
      if (res.ok) {
        setNewRef({ code: "", name: "", email: "", phone: "" });
        setShowAddRef(false);
        fetchData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleDeleteRef = async (id: string) => {
    if (!confirm("متأكد إنك عايز تمسح السيلز ده؟")) return;
    try {
      await fetch(`/api/admin/refs?id=${id}`, { method: "DELETE" });
      fetchData();
    } catch (err) {
      console.error(err);
    }
  };

  const copyLink = (code: string) => {
    const link = `${siteUrl}?ref=${code}`;
    navigator.clipboard.writeText(link);
    alert(`تم نسخ الرابط: ${link}`);
  };

  // --- LOGIN SCREEN ---
  if (!isAuthed) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#0a1628] px-4">
        <motion.form
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          onSubmit={handleLogin}
          className="w-full max-w-sm rounded-2xl border border-white/10 bg-[#0f1f3d] p-8"
        >
          <div className="mb-6 text-center">
            <div className="text-2xl font-bold mb-2">
              <span className="text-[#2db8ff]">1X</span>
              <span className="text-white">BET</span>
              <span className="text-xs text-white/40 ml-1">Admin</span>
            </div>
            <p className="text-sm text-white/50">لوحة تحكم المشرف</p>
          </div>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="كلمة السر"
            className="mb-4 w-full rounded-lg border border-white/10 bg-white/5 px-4 py-3 text-center text-white placeholder:text-white/30 outline-none focus:border-[#2db8ff]/50"
          />
          {authError && <p className="mb-3 text-center text-sm text-red-400">{authError}</p>}
          <button
            type="submit"
            className="w-full rounded-lg bg-gradient-to-r from-[#d4a017] to-[#e8b84d] py-3 text-sm font-bold text-[#0a1628] transition-all hover:shadow-lg hover:shadow-[#d4a017]/20"
          >
            دخول
          </button>
        </motion.form>
      </div>
    );
  }

  // --- DASHBOARD ---
  return (
    <div className="min-h-screen bg-[#0a1628] text-white" dir="rtl">
      {/* Top bar */}
      <div className="border-b border-white/5 bg-[#0f1f3d] px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <span className="text-xl font-bold">
            <span className="text-[#2db8ff]">1X</span>
            <span className="text-white">BET</span>
            <span className="text-xs text-white/40 mr-1">Admin</span>
          </span>
        </div>
        <button
          onClick={() => setIsAuthed(false)}
          className="rounded-lg bg-white/5 px-4 py-2 text-sm text-white/60 transition-colors hover:bg-white/10 hover:text-white"
        >
          خروج
        </button>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
        {/* Stats cards */}
        <div className="mb-8 grid gap-4 sm:grid-cols-3">
          <div className="rounded-xl border border-white/5 bg-[#0f1f3d] p-5">
            <p className="text-xs text-white/40 mb-1">إجمالي التسجيلات</p>
            <p className="text-3xl font-bold text-[#2db8ff]">{registrations.length}</p>
          </div>
          <div className="rounded-xl border border-white/5 bg-[#0f1f3d] p-5">
            <p className="text-xs text-white/40 mb-1">عدد السيلز</p>
            <p className="text-3xl font-bold text-[#d4a017]">{salesRefs.length}</p>
          </div>
          <div className="rounded-xl border border-white/5 bg-[#0f1f3d] p-5">
            <p className="text-xs text-white/40 mb-1">تسجيلات برابط سيلز</p>
            <p className="text-3xl font-bold text-green-400">{registrations.filter(r => r.refCode).length}</p>
          </div>
        </div>

        {/* Tabs */}
        <div className="mb-6 flex gap-2">
          <button
            onClick={() => setActiveTab("registrations")}
            className={`rounded-lg px-5 py-2.5 text-sm font-medium transition-colors ${
              activeTab === "registrations" ? "bg-[#2db8ff]/20 text-[#2db8ff]" : "bg-white/5 text-white/50 hover:text-white"
            }`}
          >
            التسجيلات
          </button>
          <button
            onClick={() => setActiveTab("refs")}
            className={`rounded-lg px-5 py-2.5 text-sm font-medium transition-colors ${
              activeTab === "refs" ? "bg-[#d4a017]/20 text-[#d4a017]" : "bg-white/5 text-white/50 hover:text-white"
            }`}
          >
            السيلز والروابط
          </button>
        </div>

        {/* Registrations Tab */}
        <AnimatePresence mode="wait">
          {activeTab === "registrations" && (
            <motion.div
              key="regs"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
            >
              {registrations.length === 0 ? (
                <div className="rounded-xl border border-white/5 bg-[#0f1f3d] p-12 text-center">
                  <p className="text-white/40">لا توجد تسجيلات بعد</p>
                </div>
              ) : (
                <div className="overflow-x-auto rounded-xl border border-white/5 bg-[#0f1f3d]">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-white/5 text-white/40">
                        <th className="px-4 py-3 text-right font-medium">الاسم</th>
                        <th className="px-4 py-3 text-right font-medium">البريد</th>
                        <th className="px-4 py-3 text-right font-medium">الهاتف</th>
                        <th className="px-4 py-3 text-right font-medium">الدولة</th>
                        <th className="px-4 py-3 text-right font-medium">البروموكود</th>
                        <th className="px-4 py-3 text-right font-medium">مصدر الزيارات</th>
                        <th className="px-4 py-3 text-right font-medium">رابط السيلز</th>
                        <th className="px-4 py-3 text-right font-medium">التاريخ</th>
                      </tr>
                    </thead>
                    <tbody>
                      {registrations.map((reg) => (
                        <tr key={reg.id} className="border-b border-white/5 hover:bg-white/[0.02]">
                          <td className="px-4 py-3 text-white/80">{reg.name}</td>
                          <td className="px-4 py-3 text-white/60">{reg.email}</td>
                          <td className="px-4 py-3 text-white/60" dir="ltr">{reg.phone}</td>
                          <td className="px-4 py-3 text-white/60">{reg.country}</td>
                          <td className="px-4 py-3 font-mono text-[#2db8ff]">{reg.promoCode}</td>
                          <td className="px-4 py-3 text-white/60">{reg.trafficSource}</td>
                          <td className="px-4 py-3">
                            {reg.refCode ? (
                              <span className="rounded bg-[#d4a017]/10 px-2 py-0.5 text-xs font-medium text-[#d4a017]">
                                {reg.refCode}
                              </span>
                            ) : (
                              <span className="text-white/20">—</span>
                            )}
                          </td>
                          <td className="px-4 py-3 text-white/40 text-xs" dir="ltr">
                            {new Date(reg.createdAt).toLocaleDateString("ar-EG")}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </motion.div>
          )}

          {/* Sales Refs Tab */}
          {activeTab === "refs" && (
            <motion.div
              key="refs"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
            >
              {/* Add new ref button */}
              <div className="mb-4 flex justify-between items-center">
                <h3 className="text-lg font-bold text-white">السيلز والروابط الخاصة بهم</h3>
                <button
                  onClick={() => setShowAddRef(!showAddRef)}
                  className="rounded-lg bg-gradient-to-r from-[#d4a017] to-[#e8b84d] px-4 py-2 text-sm font-bold text-[#0a1628] transition-all hover:shadow-lg hover:shadow-[#d4a017]/20"
                >
                  + إضافة سيلز جديد
                </button>
              </div>

              {/* Add ref form */}
              <AnimatePresence>
                {showAddRef && (
                  <motion.form
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    onSubmit={handleAddRef}
                    className="mb-6 overflow-hidden rounded-xl border border-[#d4a017]/20 bg-[#0f1f3d] p-6"
                  >
                    <div className="grid gap-4 sm:grid-cols-2">
                      <div>
                        <label className="mb-1 block text-xs text-white/40">كود السيلز (بالعربي أو الإنجليزي)</label>
                        <input
                          value={newRef.code}
                          onChange={(e) => setNewRef(p => ({ ...p, code: e.target.value.replace(/\s/g, "").toLowerCase() }))}
                          placeholder="مثال: ahmed"
                          className="w-full rounded-lg border border-white/10 bg-white/5 px-4 py-2.5 text-white placeholder:text-white/20 outline-none focus:border-[#2db8ff]/50"
                          required
                        />
                      </div>
                      <div>
                        <label className="mb-1 block text-xs text-white/40">الاسم</label>
                        <input
                          value={newRef.name}
                          onChange={(e) => setNewRef(p => ({ ...p, name: e.target.value }))}
                          placeholder="أحمد محمد"
                          className="w-full rounded-lg border border-white/10 bg-white/5 px-4 py-2.5 text-white placeholder:text-white/20 outline-none focus:border-[#2db8ff]/50"
                          required
                        />
                      </div>
                      <div>
                        <label className="mb-1 block text-xs text-white/40">البريد الإلكتروني (اختياري)</label>
                        <input
                          type="email"
                          value={newRef.email}
                          onChange={(e) => setNewRef(p => ({ ...p, email: e.target.value }))}
                          placeholder="ahmed@email.com"
                          className="w-full rounded-lg border border-white/10 bg-white/5 px-4 py-2.5 text-white placeholder:text-white/20 outline-none focus:border-[#2db8ff]/50"
                        />
                      </div>
                      <div>
                        <label className="mb-1 block text-xs text-white/40">رقم الهاتف (اختياري)</label>
                        <input
                          value={newRef.phone}
                          onChange={(e) => setNewRef(p => ({ ...p, phone: e.target.value }))}
                          placeholder="+20 xxx xxx xxxx"
                          className="w-full rounded-lg border border-white/10 bg-white/5 px-4 py-2.5 text-white placeholder:text-white/20 outline-none focus:border-[#2db8ff]/50"
                        />
                      </div>
                    </div>
                    <div className="mt-4 flex gap-2">
                      <button
                        type="submit"
                        className="rounded-lg bg-[#2db8ff] px-5 py-2 text-sm font-bold text-white transition-all hover:bg-[#2db8ff]/80"
                      >
                        إضافة
                      </button>
                      <button
                        type="button"
                        onClick={() => setShowAddRef(false)}
                        className="rounded-lg bg-white/5 px-5 py-2 text-sm text-white/60 transition-colors hover:text-white"
                      >
                        إلغاء
                      </button>
                    </div>
                  </motion.form>
                )}
              </AnimatePresence>

              {/* Refs list */}
              {salesRefs.length === 0 ? (
                <div className="rounded-xl border border-white/5 bg-[#0f1f3d] p-12 text-center">
                  <p className="text-white/40">لا يوجد سيلز بعد — أضف واحد جديد!</p>
                </div>
              ) : (
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  {salesRefs.map((ref) => (
                    <motion.div
                      key={ref.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="rounded-xl border border-white/5 bg-[#0f1f3d] p-5"
                    >
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="font-bold text-white">{ref.name}</h4>
                        <span className="rounded-lg bg-[#2db8ff]/10 px-2.5 py-1 text-xs font-bold text-[#2db8ff]">
                          {ref._count.registrations} تسجيل
                        </span>
                      </div>
                      <div className="mb-3 space-y-1.5 text-xs">
                        {ref.email && <p className="text-white/40">📧 {ref.email}</p>}
                        {ref.phone && <p className="text-white/40" dir="ltr">📱 {ref.phone}</p>}
                      </div>
                      {/* The ref link */}
                      <div className="mb-3 rounded-lg bg-white/[0.03] p-3">
                        <p className="mb-1 text-[10px] text-white/30">رابط السيلز:</p>
                        <p className="font-mono text-xs text-[#d4a017] break-all" dir="ltr">
                          {siteUrl}?ref={ref.code}
                        </p>
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={() => copyLink(ref.code)}
                          className="flex-1 rounded-lg bg-[#2db8ff]/10 px-3 py-2 text-xs font-medium text-[#2db8ff] transition-colors hover:bg-[#2db8ff]/20"
                        >
                          نسخ الرابط
                        </button>
                        <button
                          onClick={() => handleDeleteRef(ref.id)}
                          className="rounded-lg bg-red-500/10 px-3 py-2 text-xs font-medium text-red-400 transition-colors hover:bg-red-500/20"
                        >
                          حذف
                        </button>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
